// ═══════════════════════════════════════════════
//  Megatron — background.js v4.2
//  Compatível com Kiwi Browser (Android)
// ═══════════════════════════════════════════════
const SERVER_URL = "https://aviator-real-time-dashboard-1.onrender.com";

// Kiwi: alarms podem não funcionar — usa setInterval como fallback
let pingInterval = null;

function iniciar() {
  // Tenta criar alarmes (Chrome desktop)
  try {
    chrome.alarms.create("keepAlive",  { periodInMinutes: 0.5 });
    chrome.alarms.create("serverPing", { periodInMinutes: 4 });
  } catch(e) {}

  // Fallback para Kiwi: setInterval direto
  if (pingInterval) clearInterval(pingInterval);
  pingInterval = setInterval(() => {
    fetch(`${SERVER_URL}/api/ping`)
      .then(r => r.json())
      .then(d => console.log("[MEGATRON BG] Ping OK — online:", d.online))
      .catch(() => {});
  }, 4 * 60 * 1000); // a cada 4 minutos
}

// Inicia ao instalar
chrome.runtime.onInstalled.addListener(() => {
  iniciar();
  console.log("[MEGATRON BG] v4.2 instalado.");
});

// Inicia ao abrir o browser
chrome.runtime.onStartup.addListener(() => {
  iniciar();
});

// Alarmes (Chrome desktop)
try {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "serverPing") {
      fetch(`${SERVER_URL}/api/ping`)
        .then(r => r.json())
        .then(d => console.log("[MEGATRON BG] Ping OK:", d.online))
        .catch(() => {});
    }
  });
} catch(e) {}

// Mensagens do content.js
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "CANDLE_CAPTURED") {
    console.log("[MEGATRON BG] Vela:", msg.data);
    sendResponse({ ok: true });
  }
  return true;
});

// Inicia imediatamente (Kiwi não sempre dispara onInstalled)
iniciar();
