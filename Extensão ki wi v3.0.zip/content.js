// ═══════════════════════════════════════════════
//  Megatron — content.js v4.2
//  Compatível com Kiwi Browser (Android)
//  Baseado na v3.0 que funcionava
// ═══════════════════════════════════════════════
(function () {
  "use strict";

  const SERVER      = "https://aviator-real-time-dashboard-1.onrender.com";
  const INTERVAL_MS = 800;

  let lastMultiplier = null;
  let lastRound      = null;
  let prevCrashed    = false;
  let sending        = false;
  let lastMultSent   = null;
  let captureCount   = 0;

  // ── Extrai multiplicador do DOM ──
  function getMultiplier() {
    const selectors = [
      '[class*="multiplier"]',
      '[class*="coefficient"]',
      '[class*="crash-coeff"]',
      '[class*="current-multiplier"]',
      '[data-cy="current-multiplier"]',
      '.jet-game__coefficient',
      '.paycoeff',
      '.multiplier-value',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) {
        const v = parseFloat(el.textContent.replace(/[^0-9.]/g, '').trim());
        if (!isNaN(v) && v >= 1) return v;
      }
    }
    // Fallback: busca qualquer texto tipo "2.38x"
    const all = document.querySelectorAll('*');
    for (const el of all) {
      if (el.children.length > 0) continue;
      const txt = el.textContent.trim();
      if (/^\d+\.\d{2}x?$/.test(txt)) {
        const v = parseFloat(txt);
        if (!isNaN(v) && v >= 1 && v <= 99999) return v;
      }
    }
    return null;
  }

  // ── Extrai cor RGB ──
  function getColorRGB() {
    const sels = [
      '[class*="plane"]', '[class*="bird"]',
      '[class*="rocket"]', '[class*="jet"]',
      '[class*="craft"]', 'canvas',
    ];
    for (const sel of sels) {
      const el = document.querySelector(sel);
      if (!el) continue;
      const s = window.getComputedStyle(el);
      const bg = s.backgroundColor || s.color;
      if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') return bg;
    }
    return null;
  }

  // ── Extrai número da rodada ──
  function getRound() {
    const els = document.querySelectorAll('span, div, p');
    for (const el of els) {
      if (el.children.length > 0) continue;
      const m = el.textContent.trim().match(/[Rr]o(?:dada|und)\s+(\d+)/);
      if (m) return m[1];
    }
    const ng = document.querySelectorAll('[class*="ng-tns"]');
    for (const el of ng) {
      if (el.children.length > 0) continue;
      const m = el.textContent.trim().match(/(\d{5,})/);
      if (m) return m[1];
    }
    return null;
  }

  // ── Detecta se crashou ──
  function isCrashed() {
    const sels = [
      '[class*="crashed"]', '[class*="fly-away"]',
      '[class*="game-over"]', '[class*="round-end"]',
    ];
    for (const s of sels) if (document.querySelector(s)) return true;
    if (/(flew away|voou|crashed|fim de rodada)/i.test(document.body.textContent)) return true;
    return false;
  }

  // ── Envia vela fechada ──
  async function sendCandle(multiplier, color_rgb, round) {
    if (sending) return;
    sending = true;
    try {
      const resp = await fetch(`${SERVER}/api/candle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ multiplier, color_rgb, round }),
      });
      if (resp.ok) {
        console.log(`[MEGATRON] ✅ ${multiplier}x enviado`);
        try {
          chrome.runtime.sendMessage({
            type: 'CANDLE_CAPTURED',
            data: { multiplier, round }
          });
        } catch(_) {}
      }
    } catch(e) {
      console.warn('[MEGATRON] ❌ Erro:', e.message);
    } finally {
      sending = false;
    }
  }

  // ── Envia multiplicador em tempo real ──
  function sendMultRT(mult) {
    if (lastMultSent !== null && Math.abs(mult - lastMultSent) < 0.01) return;
    lastMultSent = mult;
    fetch(`${SERVER}/api/mult`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mult, ts: Date.now() }),
    }).catch(() => {});
  }

  // ── Loop principal ──
  function loop() {
    try {
      const crashed = isCrashed();
      const mult    = getMultiplier();
      const round   = getRound();

      // Multiplicador crescente — envia em tempo real
      if (!crashed && mult !== null && mult >= 1) {
        sendMultRT(mult);
      }

      // Crash detectado — envia vela
      if (!prevCrashed && crashed && mult !== null) {
        const roundId = round || lastRound || null;
        if (mult !== lastMultiplier || roundId !== lastRound) {
          lastMultiplier = mult;
          lastRound      = roundId;
          captureCount++;
          console.log(`[MEGATRON] 🎯 ${mult}x | #${captureCount}`);
          sendCandle(mult, getColorRGB(), roundId);
          lastMultSent = null;
        }
      }

      prevCrashed = crashed;
      if (round) lastRound = round;

    } catch(e) {
      console.warn('[MEGATRON] loop erro:', e.message);
    }

    setTimeout(loop, INTERVAL_MS);
  }

  // ── Inicia ──
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(loop, 2000));
  } else {
    setTimeout(loop, 2000);
  }

  console.log('[MEGATRON] ✅ v4.2 carregado em:', window.location.href);
})();
