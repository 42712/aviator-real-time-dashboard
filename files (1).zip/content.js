// Aviator Live Capture — content.js v4.1
// ✅ Anti-throttle  ✅ Cor RGB  ✅ Número da rodada  ✅ URL corrigida

const SERVER_URL = "https://aviator-real-time-dashboard-1.onrender.com";
let lastValue = null;
let tentativas = 0;

// ANTI-THROTTLE
function keepAlive() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    gain.gain.value = 0;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    setInterval(() => { if (ctx.state === "suspended") ctx.resume(); }, 20000);
    console.log("[Aviator] Anti-throttle ativo");
  } catch(e) {}
}

// COR RGB
function extractRgb(el) {
  try {
    const inlineColor = el.style.color;
    if (inlineColor && inlineColor.startsWith("rgb")) return inlineColor.replace(/[^0-9,]/g,"").replace(/,$/,"");
    const computed = window.getComputedStyle(el).color;
    if (computed && computed.startsWith("rgb")) return computed.replace(/[^0-9,]/g,"").replace(/,$/,"");
  } catch(e) {}
  return null;
}

// NÚMERO DA RODADA
function extractRound() {
  try {
    const spans = document.querySelectorAll('span.text-uppercase[class*="ng-tns-c45-"]');
    for (const span of spans) {
      const match = (span.innerText || span.textContent || "").trim().match(/\d{5,}/);
      if (match) return match[0];
    }
    const allSpans = document.querySelectorAll("span.text-uppercase");
    for (const span of allSpans) {
      const match = (span.innerText || span.textContent || "").trim().match(/\d{5,}/);
      if (match) return match[0];
    }
  } catch(e) {}
  return null;
}

// CAPTURA
function capture() {
  const payouts = document.querySelectorAll(".payout");
  if (!payouts.length) {
    tentativas++;
    if (tentativas < 5) console.log("[Aviator] Aguardando .payout... tentativa", tentativas);
    return;
  }
  tentativas = 0;

  const el    = payouts[0];
  const raw   = (el.innerText || el.textContent || "").trim();
  const value = parseFloat(raw.replace(/x/gi,"").replace(",",".").trim());

  if (!value || isNaN(value) || value < 1 || value > 10000) return;
  if (value === lastValue) return;
  lastValue = value;

  const rgb   = extractRgb(el);
  const round = extractRound();

  console.log("[Aviator] Vela:", value, "| Rodada:", round || "?", "| Cor:", rgb || "?");

  fetch(`${SERVER_URL}/api/candle`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      multiplier: value,
      color_rgb:  rgb   || null,
      round:      round || null,
      timestamp:  new Date().toISOString()
    }),
    keepalive: true
  })
  .then(r => console.log("[Aviator] Enviado! Status:", r.status))
  .catch(e => console.log("[Aviator] Erro:", e));
}

// PING SERVIDOR
function pingServer() {
  fetch(`${SERVER_URL}/api/ping`).catch(() => {});
}

keepAlive();
setInterval(capture, 1000);
setInterval(pingServer, 2 * 60 * 1000);
