// Aviator Live Capture — background.js v3.0
const SERVER_URL = "https://aviator-real-time-dashboard-1.onrender.com";

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("keepAlive",  { periodInMinutes: 1 });
  chrome.alarms.create("serverPing", { periodInMinutes: 2 });
  console.log("[BG] Alarmes criados.");
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("keepAlive",  { periodInMinutes: 1 });
  chrome.alarms.create("serverPing", { periodInMinutes: 2 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "keepAlive") {
    console.log("[BG] KeepAlive tick:", new Date().toLocaleTimeString());
  }
  if (alarm.name === "serverPing") {
    fetch(`${SERVER_URL}/api/ping`)
      .then(r => console.log("[BG] Ping:", r.status))
      .catch(() => {});
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "AVIATOR_PING") sendResponse({ alive: true });
});
