// Aviator Live Capture — content.js v5.0
// ✅ Anti-throttle  ✅ Cor RGB  ✅ Rodada CORRIGIDA (ng-tns-c45-3)  ✅ Modal/iframe

const SERVER_URL = "https://aviator-real-time-dashboard-1.onrender.com";
let lastValue = null;
let lastRound = null;
let tentativas = 0;

// ANTI-THROTTLE
function keepAlive() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    gain.gain.value = 0;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    setInterval(() => { if (ctx.state === "suspended") ctx.resume(); }, 20000);
    console.log("[Aviator] Anti-throttle ativo");
  } catch(e) {}
}

// COR RGB
function extractRgb(el) {
  try {
    const inlineColor = el.style.color;
    if (inlineColor && inlineColor.startsWith("rgb")) return inlineColor.replace(/[^0-9,]/g,"").replace(/,$/,"");
    const computed = window.getComputedStyle(el).color;
    if (computed && computed.startsWith("rgb")) return computed.replace(/[^0-9,]/g,"").replace(/,$/,"");
  } catch(e) {}
  return null;
}

// ═══════════════════════════════════════════════
// NÚMERO DA RODADA — seletor correto confirmado
// <span class="text-uppercase ng-tns-c45-3"> Rodada 3458014 </span>
// Busca em: página principal, modals, body, iframes
// ═══════════════════════════════════════════════
function extractRound() {
  try {
    // Busca em todos os documentos acessíveis
    const docs = [document];
    // Adiciona iframes acessíveis
    document.querySelectorAll("iframe").forEach(fr => {
      try { if (fr.contentDocument) docs.push(fr.contentDocument); } catch(e) {}
    });

    for (const doc of docs) {
      // MÉTODO 1 — seletor exato confirmado pelo print
      // class="text-uppercase ng-tns-c45-3" (sem underscore no início)
      const spans = doc.querySelectorAll('span.text-uppercase[class*="ng-tns-c"]');
      for (const span of spans) {
        const txt = (span.innerText || span.textContent || "").trim();
        // Formato: "Rodada 3458014"
        const m = txt.match(/[Rr]odada\s+(\d{4,})/);
        if (m) { console.log("[Aviator] Rodada encontrada (método 1):", m[1]); return m[1]; }
        // Só número longo sozinho
        const m2 = txt.match(/^(\d{5,})$/);
        if (m2) { console.log("[Aviator] Rodada encontrada (método 2):", m2[1]); return m2[1]; }
      }

      // MÉTODO 2 — busca por texto "Rodada XXXXX" em qualquer lugar do DOM
      const all = doc.querySelectorAll("span, div, h1, h2, h3, p, label");
      for (const el of all) {
        if (el.children.length > 0) continue;
        const txt = (el.innerText || el.textContent || "").trim();
        const m = txt.match(/[Rr]odada\s+(\d{4,})/);
        if (m) { console.log("[Aviator] Rodada encontrada (método 3):", m[1]); return m[1]; }
        const mR = txt.match(/[Rr]ound\s+(\d{4,})/);
        if (mR) { console.log("[Aviator] Round encontrado (método 4):", mR[1]); return mR[1]; }
      }

      // MÉTODO 3 — busca pelo header do modal que mostra "RODADA 3458014"
      // O header fica em: div.modal-header.canSelect.ng-tns-c45-3
      const headers = doc.querySelectorAll('[class*="modal-header"]');
      for (const h of headers) {
        const txt = (h.innerText || h.textContent || "").trim();
        const m = txt.match(/[Rr][Oo][Dd][Aa][Dd][Aa]\s+(\d{4,})/);
        if (m) { console.log("[Aviator] Rodada encontrada (modal header):", m[1]); return m[1]; }
      }
    }

    // MÉTODO 4 — lê direto do título da página ou qualquer texto visível
    const bodyText = document.body ? (document.body.innerText || "") : "";
    const mBody = bodyText.match(/[Rr]odada\s+(\d{5,})/);
    if (mBody) { console.log("[Aviator] Rodada encontrada (body):", mBody[1]); return mBody[1]; }

  } catch(e) { console.log("[Aviator] Erro extractRound:", e.message); }
  return null;
}

// CAPTURA MULTIPLICADOR
function capture() {
  let payouts = document.querySelectorAll(".payout");
  if (!payouts.length) {
    document.querySelectorAll("iframe").forEach(fr => {
      try {
        const fp = fr.contentDocument.querySelectorAll(".payout");
        if (fp.length) payouts = fp;
      } catch(e) {}
    });
  }

  if (!payouts.length) {
    tentativas++;
    if (tentativas < 5) console.log("[Aviator] Aguardando .payout... tentativa", tentativas);
    return;
  }
  tentativas = 0;

  const el    = payouts[0];
  const raw   = (el.innerText || el.textContent || "").trim();
  const value = parseFloat(raw.replace(/x/gi,"").replace(",",".").trim());

  if (!value || isNaN(value) || value < 1 || value > 100000) return;
  if (value === lastValue) return;
  lastValue = value;

  const rgb   = extractRgb(el);
  const round = extractRound();
  if (round) lastRound = round;

  console.log("[Aviator] ✅ Vela:", value, "| Rodada:", round || lastRound || "?", "| Cor:", rgb || "?");

  fetch(`${SERVER_URL}/api/candle`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      multiplier: value,
      color_rgb:  rgb || null,
      round:      round || lastRound || null,
      timestamp:  new Date().toISOString()
    }),
    keepalive: true
  })
  .then(r => console.log("[Aviator] Enviado! Status:", r.status))
  .catch(e => console.log("[Aviator] Erro:", e));
}

// PING
function pingServer() {
  fetch(`${SERVER_URL}/api/ping`).catch(() => {});
}

// TESTE MANUAL — abre o console e digita: testRound()
window.testRound = function() {
  const r = extractRound();
  console.log("[Aviator] TEST ROUND:", r || "NÃO ENCONTRADO");
  return r;
};

keepAlive();
setInterval(capture, 1000);
setInterval(pingServer, 2 * 60 * 1000);
console.log("[Aviator v5.0] Iniciado! Digite testRound() no console para testar.");
