// MEGATRON popup.js v8.1 MV3
var SERVER = "https://aviator-real-time-dashboard-1.onrender.com";

document.getElementById("btnPainel").onclick = function() {
  chrome.tabs.create({ url: SERVER });
};

document.getElementById("btnTestar").onclick = function() {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (!tabs || !tabs[0]) { alert("Nenhuma aba ativa"); return; }
    chrome.tabs.sendMessage(tabs[0].id, { type: "TEST_CAPTURE" }, function(resp) {
      if (chrome.runtime.lastError) {
        alert("Extensao nao ativa nesta pagina.\nAbra o Aviator primeiro.");
        return;
      }
      if (resp && resp.status === "OK") {
        alert("OK!\nMult: " + (resp.multiplier || "-") +
              "\nRodada: " + (resp.round || "-") +
              "\nURL: " + (resp.url || "-"));
      } else {
        alert("Sem resposta do content script");
      }
    });
  });
};

// Verifica status do servidor
fetch(SERVER + "/api/status")
  .then(function(r) { return r.json(); })
  .then(function(d) {
    document.getElementById("srv").textContent = "Online";
    document.getElementById("srv").className = "val";
    document.getElementById("cnt").textContent = (d.candles || 0) + " velas";
    if (d.lastCandle && d.lastCandle.multiplier) {
      document.getElementById("ult").textContent = d.lastCandle.multiplier.toFixed(2) + "x";
    }
  })
  .catch(function() {
    document.getElementById("srv").textContent = "Offline";
    document.getElementById("srv").className = "val err";
  });
