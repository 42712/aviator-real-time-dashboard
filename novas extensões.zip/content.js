// MEGATRON content.js v9.1
// WebSocket intercept + DOM rodada exato
// Kiwi MV3 - Pure ASCII
(function() {
  "use strict";

  var SERVER    = "https://aviator-real-time-dashboard-1.onrender.com";
  var MIN_DELAY = 3000;

  var lastSent  = 0;
  var sending   = false;
  var wsActive  = false;

  // -----------------------------------------------
  // RODADA - seletor exato do Angular Spribe
  // -----------------------------------------------
  function getRound() {
    var sels = [
      'span.text-uppercase[class*="ng-tns"]',
      '[class*="ng-tns"] span.text-uppercase',
      'span[class*="text-uppercase"][class*="ng-tns"]'
    ];
    for (var i = 0; i < sels.length; i++) {
      var els = document.querySelectorAll(sels[i]);
      for (var j = 0; j < els.length; j++) {
        var t = (els[j].textContent || "").trim();
        var m = t.match(/[Rr]odada\s+(\d+)/);
        if (m) return m[1];
        if (/^\d{5,8}$/.test(t)) return t;
      }
    }
    var all = document.querySelectorAll("span,div,p");
    for (var k = 0; k < all.length; k++) {
      if (all[k].children.length > 0) continue;
      var t2 = (all[k].textContent || "").trim();
      var m2 = t2.match(/[Rr]odada\s+(\d{4,})/);
      if (m2) return m2[1];
    }
    return null;
  }

  // -----------------------------------------------
  // ENVIA VELA AO SERVIDOR
  // -----------------------------------------------
  function enviar(mult, round, timestamp) {
    if (sending) return;
    if (Date.now() - lastSent < MIN_DELAY) return;
    if (!mult || mult < 1.01) return;

    sending = true;
    lastSent = Date.now();

    var rodada = round || getRound();
    var ts     = timestamp || new Date().toISOString();

    var body = JSON.stringify({
      multiplier: parseFloat(mult.toFixed(2)),
      color_rgb:  null,
      round:      rodada,
      timestamp:  ts
    });

    console.log("[MEGATRON v9.1] enviando " + mult.toFixed(2) + "x | rodada=" + rodada);

    function tentar(n) {
      fetch(SERVER + "/api/candle", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    body,
        mode:    "cors"
      })
      .then(function(r) {
        sending = false;
        if (r.ok) {
          console.log("[MEGATRON v9.1] OK " + mult.toFixed(2) + "x");
          try { chrome.runtime.sendMessage({ type: "CANDLE_CAPTURED", data: { multiplier: mult, round: rodada } }); } catch(e) {}
        }
      })
      .catch(function(e) {
        if (n < 3) setTimeout(function() { tentar(n+1); }, 2000);
        else sending = false;
      });
    }
    tentar(1);
  }

  // -----------------------------------------------
  // INTERCEPTA WEBSOCKET
  // -----------------------------------------------
  function interceptarWS() {
    if (wsActive) return;

    var OldWS = window.WebSocket;
    if (!OldWS) return;

    window.WebSocket = function(url, protocols) {
      var ws = protocols ? new OldWS(url, protocols) : new OldWS(url);

      if (url && url.indexOf("spribegaming.com") >= 0) {
        wsActive = true;
        console.log("[MEGATRON v9.1] WS conectado:", url);

        var roundAtual = null;
        var multPico   = 0;
        var emRodada   = false;

        ws.addEventListener("message", function(event) {
          var raw = event.data;

          function processar(txt) {
            if (txt && txt.length < 500) {
              var mCoef = txt.match(/"(?:coef|coefficient|multiplier|c|k|x|v|rate|factor|current)"\s*:\s*(\d+\.?\d*)/i);
              var mBare = txt.match(/\b(\d{1,4}\.\d{1,2})\b/);
              var mRound = txt.match(/"(?:round|round_id|roundId|gameId|game_id|id|r|rid)"\s*:\s*"?(\d{4,})"?/i);
              if (mRound) roundAtual = mRound[1];

              if (/"(?:start|begin|new_game|newGame|game_start|phase)"\s*:\s*"?(?:start|begin|1|true|fly)"?/i.test(txt)) {
                emRodada = true;
                multPico = 1.0;
                console.log("[MEGATRON v9.1] inicio rodada | round=" + roundAtual);
              }

              var mult = null;
              if (mCoef) mult = parseFloat(mCoef[1]);
              else if (mBare) mult = parseFloat(mBare[1]);

              if (mult && mult >= 1.0 && mult <= 10000) {
                if (mult > multPico) multPico = mult;
              }

              var isCrash = /"(?:crash|crashed|end|finish|result|payout|cashout|fly_away|flew)"\s*:/i.test(txt);
              if (!isCrash) isCrash = /"(?:phase|status|state)"\s*:\s*"?(?:crash|crashed|end|finish|over|result)"?/i.test(txt);

              if (isCrash && emRodada) {
                emRodada = false;
                var final = multPico > 1.01 ? multPico : (mult || 1.0);
                var ts = new Date().toISOString();
                console.log("[MEGATRON v9.1] CRASH WS " + final.toFixed(2) + "x | round=" + roundAtual);
                enviar(final, roundAtual, ts);
                multPico = 0;
              }
            }
          }

          if (typeof raw === "string") {
            processar(raw);
          } else if (raw instanceof Blob) {
            raw.text().then(processar).catch(function(){});
          } else if (raw instanceof ArrayBuffer) {
            processar(new TextDecoder().decode(raw));
          }
        });
      }
      return ws;
    };

    for (var k in OldWS) {
      try { window.WebSocket[k] = OldWS[k]; } catch(e) {}
    }
    window.WebSocket.prototype = OldWS.prototype;
    console.log("[MEGATRON v9.1] WebSocket interceptado");
  }

  // -----------------------------------------------
  // FALLBACK DOM
  // -----------------------------------------------
  var lastMult  = null;
  var pico      = 0;
  var stableN   = 0;
  var enviada   = false;

  function getMult() {
    var sels = [
      'div[class*="multiplier"]','span[class*="multiplier"]',
      'div[class*="coefficient"]','span[class*="coefficient"]',
      '[class*="crash-coeff"]','[class*="current-multiplier"]'
    ];
    for (var i = 0; i < sels.length; i++) {
      var els = document.querySelectorAll(sels[i]);
      for (var j = 0; j < els.length; j++) {
        if (els[j].children.length > 0) continue;
        var m = (els[j].textContent || "").trim().match(/(\d+[.,]\d+)\s*x/i);
        if (m) {
          var v = parseFloat(m[1].replace(",", "."));
          if (v >= 1.0 && v <= 10000) return v;
        }
      }
    }
    return null;
  }

  function loopDOM() {
    if (!wsActive) {
      var mult = getMult();
      if (mult !== null && mult > 1.0) {
        if (mult > pico) pico = mult;
        if (lastMult !== null && Math.abs(mult - lastMult) < 0.01) stableN++;
        else stableN = 0;
      }
      if (!enviada && stableN >= 5 && pico > 1.1) {
        enviada = true;
        enviar(pico, getRound(), new Date().toISOString());
        pico = 0; stableN = 0;
      }
      if (lastMult !== null && lastMult < 1.10 && mult !== null && mult > 1.10) {
        enviada = false; pico = 0; stableN = 0;
      }
      lastMult = mult;
    }
    setTimeout(loopDOM, 500);
  }

  // -----------------------------------------------
  // POPUP TEST
  // -----------------------------------------------
  try {
    chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
      if (msg && msg.type === "TEST_CAPTURE") {
        sendResponse({ status: "OK", multiplier: getMult(), round: getRound(), url: window.location.href, ws: wsActive });
      }
      return true;
    });
  } catch(e) {}

  // -----------------------------------------------
  // INICIA
  // -----------------------------------------------
  console.log("[MEGATRON v9.1] iniciando em:", window.location.href);

  interceptarWS();
  setTimeout(interceptarWS, 1000);
  setTimeout(loopDOM, 3000);

  fetch(SERVER + "/api/ping").catch(function(){});

})();
