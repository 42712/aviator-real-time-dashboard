// MEGATRON background.js v8.1 MV3
// Service Worker - usa chrome.alarms para ping periodico

var SERVER = "https://aviator-real-time-dashboard-1.onrender.com";

function ping() {
  fetch(SERVER + "/api/ping", { method: "GET", mode: "cors" })
    .then(function(r) { return r.json(); })
    .then(function(d) { console.log("[BG] ping OK | velas:", d.candles); })
    .catch(function(e) { console.log("[BG] ping falhou:", e.message); });
}

// Alarm a cada 2 minutos para manter Render acordado
chrome.alarms.create("ping", { periodInMinutes: 2 });

chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm.name === "ping") ping();
});

// Ping inicial
ping();

// Recebe confirmacao de vela capturada pelo content.js
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg && msg.type === "CANDLE_CAPTURED") {
    console.log("[BG] vela:", msg.data.multiplier + "x | rodada=" + msg.data.round);
  }
  sendResponse({ ok: true });
  return true;
});

console.log("[BG] v8.1 MV3 iniciado");
